package com.pope.contract.util;

import java.math.BigDecimal;

public class ConstantUtil {

	public static final String USER_SESSION_NAME="USER_SESSION";
	
	/**
	 * 默认密码
	 */
	public static final String DEFAULT_PASSWORD="123456";
	
}
