package com.pope.contract.util;

import java.util.Map;

public class SequenceUtil {
//	/**
//	 * 获取项目编号
//	 * @return
//	 * @throws Exception
//	 */
//	public static synchronized String getXmbh() throws Exception {
//		String code="";
//		Map<String,Object> data=ActionUtil.queryOne("hqxmbh");
//		if(CommonUtil.isNotEmptyMap(data)){
//			code=ConvertUtil.strOf(data.get("CODE"));
//		}
//		return code;
//	}
//	
//	public static synchronized String getRwbh() throws Exception{
//		String code="";
//		Map<String,Object> data=ActionUtil.queryOne("hqrwbh");
//		if(CommonUtil.isNotEmptyMap(data)){
//			code=ConvertUtil.strOf(data.get("CODE"));
//		}
//		return code;
//	}
}
